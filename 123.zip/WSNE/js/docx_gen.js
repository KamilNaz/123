// docx_gen.js — Generowanie pliku DOCX (Meldunek Bieżący)
// Wymaga: docx.umd.min.js (window.docx) + pdf.js (ORZEL_B64, buildTrzStr)
(function() {
'use strict';

document.getElementById('btnGenerujDOCX').addEventListener('click', async function() {
  const {
    Document, Packer, Table, TableRow, TableCell, Paragraph, TextRun, ImageRun,
    WidthType, BorderStyle, ShadingType, AlignmentType, UnderlineType, VerticalAlign
  } = window.docx;

  // ─── Dane z formularza (identyczne jak pdf.js) ───────────────────────────
  function s(v){ return (v && typeof v === 'string') ? v : ''; }
  function fmtDate(d) {
    if(!d) return '___________';
    const parts = d.split('-');
    if(parts.length < 3) return '___________';
    return parts[2]+'.'+parts[1]+'.'+parts[0]+' r.';
  }

  const nr         = s(document.getElementById('nrMeldunku').value)    || '___';
  const dataMeldRaw= document.getElementById('dataMeldunku').value;
  const rok        = dataMeldRaw ? dataMeldRaw.split('-')[0] : '2026';
  const dataMeld   = fmtDate(dataMeldRaw);
  const miejsc     = s(document.getElementById('miejscowosc').value)    || 'Elbląg';
  const oficer     = s(document.getElementById('oficerDyzurny').value)  || '_______________';
  const dataZdarz  = fmtDate(document.getElementById('dataZdarzenia').value);
  const godz       = s(document.getElementById('godzinaZdarzenia').value) || '__:__';
  const miejsce    = s(document.getElementById('miejsceZdarzenia').value) || '_______________';
  const _katMain   = document.getElementById('kategoriaZdarzenia');
  const _katSub    = document.getElementById('katSubZdarzenia');
  const kat        = s(_katSub && _katSub.value ? _katSub.value : _katMain ? _katMain.value : '') || '_______________';

  const stopien    = s(document.getElementById('stopienSprawcy').value);
  const imie       = s(document.getElementById('imieSprawcy').value);
  const nazwisko   = s(document.getElementById('nazwiskoSprawcy').value);
  const imieOjca   = s(document.getElementById('imieOjcaSprawcy').value);
  const pesel      = s(document.getElementById('peselSprawcy').value);
  const jednostka  = s(document.getElementById('jednostkaSprawcy').value) || '_______________';
  const miejscJW   = s(document.getElementById('miejscowoscJW').value)    || '_______________';
  const podleglosc = s(document.getElementById('podlegloscJW').value)     || '_______________';

  const opis       = s(document.getElementById('opisZdarzenia').value) || '_______________';
  const kwalArr    = Array.from(document.querySelectorAll('input[name="kwalifikacja"]:checked')).map(cb=>cb.value);
  const kwalDop    = s(document.getElementById('kwalDodatkowe').value).trim();
  let kwalBody = '';
  if(kwalArr.length) kwalBody = kwalArr.join(', ');
  if(kwalDop) kwalBody += (kwalBody ? '\n' : '') + kwalDop;

  const losArr  = Array.from(document.querySelectorAll('input[name="losSprawcy"]:checked')).map(cb=>cb.value);
  const losDod  = s(document.getElementById('losDodatkowe').value).trim();
  const losParts = [];
  if(losDod) losParts.push(losDod);
  if(losArr.length) losParts.push(...losArr.map(v=>'- '+v));
  const los      = losParts.length ? losParts.join('\n') : '_______________';
  const losOsoba = (document.querySelector('input[name="losOsoba"]:checked')||{}).value || null;

  const sprDane   = s((document.getElementById('sprawcaTrzezwosc_dane')||{}).value).trim();
  const uczDane   = s((document.getElementById('uczestnikTrzezwosc_dane')||{}).value).trim();
  const trzSprStr = (typeof buildTrzStr === 'function') ? buildTrzStr('spr') : '';
  const trzUczStr = (typeof buildTrzStr === 'function') ? buildTrzStr('ucz') : '';
  function hasTrzData(prefix) {
    for(var i=1;i<=3;i++){
      var nb=document.getElementById(prefix+'B'+i+'nb');
      var v=document.getElementById(prefix+'B'+i+'val');
      if((nb&&nb.checked)||(v&&v.value.trim()!=='')) return true;
    }
    return false;
  }
  const sprHasTrz = hasTrzData('spr');
  const uczHasTrz = hasTrzData('ucz');
  const sprHasDrg = !!(document.getElementById('sprOdurz')||{}).checked;
  const uczHasDrg = !!(document.getElementById('uczOdurz')||{}).checked;
  const sprHasAny = sprHasTrz || sprHasDrg;
  const uczHasAny = uczHasTrz || uczHasDrg;
  const sprDaneTxt = sprHasAny ? (sprDane||'---') : '_______________';
  const uczDaneTxt = uczHasAny ? (uczDane||'---') : '_______________';
  const anyAlk = sprHasTrz || uczHasTrz;
  const anyDrg = sprHasDrg || uczHasDrg;

  const instBloki = document.querySelectorAll('#instytucjeContainer .inst-block');
  const czynnosciLines = [];
  instBloki.forEach(blok=>{
    const instName = blok.querySelector('.inst-select').value;
    const checked  = Array.from(blok.querySelectorAll('.inst-czyn:checked')).map(cb=>'- '+cb.value);
    const dop      = blok.querySelector('.inst-dop').value.trim();
    if(instName||checked.length||dop){
      if(instName) czynnosciLines.push({text: instName+':', underline: true});
      checked.forEach(c => czynnosciLines.push({text: c, underline: false}));
      if(dop) czynnosciLines.push({text: '- '+dop, underline: false});
    }
  });

  const przymusArr = Array.from(document.querySelectorAll('input[name="przymus"]:checked')).map(cb=>cb.value);
  const przymusDopTxt = s(document.getElementById('przymusDodatkowe').value).trim();
  let przymus = '';
  if(przymusArr.length){
    if(przymusArr[0]==='Nie stosowano środków przymusu bezpośredniego.'){
      przymus = 'Nie stosowano.';
    } else {
      przymus = 'Zastosowano: '+przymusArr.join(', ')+'.';
      if(przymusDopTxt) przymus += ' '+przymusDopTxt;
    }
  } else {
    przymus = przymusDopTxt || 'Nie stosowano.';
  }

  const post       = s(document.getElementById('sposobPostep').value).trim() || '_______________';
  const firstBlok  = document.querySelector('#instytucjeContainer .inst-block');
  const inst       = firstBlok ? s(firstBlok.querySelector('.inst-select').value)||'_______________' : '_______________';
  const dalszePost = s(document.getElementById('dalszePosto').value);
  const dalszeDop  = s(document.getElementById('dalszePostoDop').value).trim();
  const dalsze     = dalszeDop || dalszePost || '_______________';
  const uwagi      = s(document.getElementById('inneUwagi').value) || '_______________';

  // ─── Layout w DXA (1mm ≈ 56.7 DXA) ────────────────────────────────────────
  // PDF: CW=171.8mm, COL=[32.4, 40.0, 35.0, 35.0, 37.5]mm, suma=179.9mm
  // Skalujemy do CW: k=171.8/179.9
  const CW_DXA   = 9741; // 171.8mm
  const COL_RAW  = [32.4, 40.0, 35.0, 35.0, 37.5];
  const SUM_COL  = 179.9;
  const COL_DXA  = COL_RAW.map(mm => Math.round(mm / SUM_COL * CW_DXA));
  // Korekta: dopasuj sumę do CW_DXA
  const diff = CW_DXA - COL_DXA.reduce((a,b)=>a+b,0);
  COL_DXA[4] += diff;
  const COL_REST_DXA = COL_DXA[1]+COL_DXA[2]+COL_DXA[3]+COL_DXA[4];
  const COL12_DXA    = COL_DXA[1]+COL_DXA[2];

  // ─── Stałe stylu ────────────────────────────────────────────────────────────
  const SZ    = 20; // 10pt (half-points)
  const SZ8   = 16; // 8pt
  const SZ12  = 24; // 12pt
  const SZ_SIG= 24; // podpis 12pt
  const GRAY  = 'D9D9D9';
  const FONT  = 'Arial';
  const CMARG = { top: 57, bottom: 57, left: 108, right: 108 };
  // CMARG: 1.9mm = 108 twips (l/r — identyczne z PDF px=1.9), 1mm = 57 twips (t/b)
  const TB    = { style: BorderStyle.SINGLE, size: 4, color: '000000' };
  const NB    = { style: BorderStyle.NONE,   size: 0, color: 'FFFFFF' };
  const BALL  = { top: TB, bottom: TB, left: TB, right: TB };
  const BNONE = { top: NB, bottom: NB, left: NB, right: NB };
  const SP240 = { line: 240 };
  const SP252 = { line: 236 };
  // SP252 = 236 twips ≈ 10pt × 1.18 × 20 — identyczne z PDF: lh=sz*0.3528*1.18

  // ─── Pomocnicze: konwersja tekstu wieloliniowego na akapity ─────────────────
  function multiPara(text, opts) {
    const o = opts || {};
    const sz = o.sz || SZ;
    const al = o.align || AlignmentType.LEFT;
    const sp = o.spacing || SP252;
    return (text||'').split('\n').map(line => new Paragraph({
      children: [new TextRun({ text: line, size: sz, bold: o.bold||false, font: FONT })],
      alignment: al, spacing: sp
    }));
  }

  // ─── Pomocnicze: komórka szara (etykieta) ────────────────────────────────────
  function gCell(children_or_text, widthDXA, opts) {
    const o = opts || {};
    const ch = (typeof children_or_text === 'string')
      ? multiPara(children_or_text, { sz: SZ8, align: o.align || AlignmentType.LEFT })
      : children_or_text;
    return new TableCell({
      shading: { type: ShadingType.SOLID, color: GRAY, fill: GRAY },
      borders: BALL,
      width:  { size: widthDXA, type: WidthType.DXA },
      margins: CMARG,
      children: ch,
      verticalAlign: o.va || VerticalAlign.CENTER,
      rowSpan: o.rowSpan,
      columnSpan: o.colSpan
    });
  }

  // ─── Pomocnicze: komórka biała (wartość) ──────────────────────────────────────
  function wCell(children_or_text, widthDXA, opts) {
    const o = opts || {};
    const ch = (typeof children_or_text === 'string')
      ? multiPara(children_or_text || '_______________', { sz: o.sz||SZ, bold: o.bold||false, align: o.align||AlignmentType.LEFT })
      : children_or_text;
    return new TableCell({
      borders: BALL,
      width:   { size: widthDXA, type: WidthType.DXA },
      margins: CMARG,
      children: ch,
      verticalAlign: o.va || VerticalAlign.CENTER,
      rowSpan: o.rowSpan,
      columnSpan: o.colSpan
    });
  }

  // ─── Pomocnicze: pusty wiersz ────────────────────────────────────────────────
  function emptyPara(sz) {
    return new Paragraph({ children: [new TextRun({ text: '', size: sz||SZ, font: FONT })], spacing: SP240 });
  }

  // ─── Orzeł — konwersja base64 → Uint8Array ──────────────────────────────────
  let eagleBytes = null;
  try {
    if(typeof ORZEL_B64 !== 'undefined' && ORZEL_B64) {
      eagleBytes = Uint8Array.from(atob(ORZEL_B64), c => c.charCodeAt(0));
    }
  } catch(e) { eagleBytes = null; }

  // 13mm @ 96dpi ≈ 49px
  const EAGLE_PX = 49;
  const eaglePara = eagleBytes
    ? new Paragraph({
        children: [new ImageRun({ data: eagleBytes, transformation: { width: EAGLE_PX, height: EAGLE_PX } })],
        alignment: AlignmentType.CENTER,
        spacing: { after: 40 }
      })
    : emptyPara(SZ12);

  // ─── NAGŁÓWEK (tabela bez ramek: orzeł+jednostka | DSO | data) ──────────────
  // Proporcje nagłówka zgodne z PDF (Eagle BOX_W=85.9mm ≈ 40% CW, DSO ≈ 45%, Date ≈ 15%)
  const LEFT_W2  = Math.round(CW_DXA * 0.40);  // ~3896 DXA ≈ 68.7mm
  const DSO_W2   = Math.round(CW_DXA * 0.45);  // ~4384 DXA ≈ 77.3mm
  const DATE_W2  = CW_DXA - LEFT_W2 - DSO_W2;  // ~1461 DXA ≈ 25.8mm

  const headerTable = new Table({
    width: { size: CW_DXA, type: WidthType.DXA },
    borders: BNONE,
    rows: [
      new TableRow({
        children: [
          // Lewa: Orzeł + Jednostka
          new TableCell({
            borders: BNONE,
            width: { size: LEFT_W2, type: WidthType.DXA },
            verticalAlign: VerticalAlign.TOP,
            children: [
              eaglePara,
              new Paragraph({ children: [new TextRun({ text: 'ODDZIAŁ', bold: true, size: SZ12, font: FONT })], alignment: AlignmentType.CENTER, spacing: SP240 }),
              new Paragraph({ children: [new TextRun({ text: 'ŻANDARMERII WOJSKOWEJ', bold: true, size: SZ12, font: FONT })], alignment: AlignmentType.CENTER, spacing: SP240 }),
              new Paragraph({ children: [new TextRun({ text: 'W ELBLĄGU', bold: true, size: SZ12, font: FONT })], alignment: AlignmentType.CENTER, spacing: SP240 }),
            ]
          }),
          // Środkowa: DSO
          new TableCell({
            borders: BNONE,
            width: { size: DSO_W2, type: WidthType.DXA },
            verticalAlign: VerticalAlign.BOTTOM,
            children: [
              emptyPara(SZ12),
              emptyPara(SZ12),
              new Paragraph({ children: [new TextRun({ text: 'DYŻURNA SŁUŻBA OPERACYJNA', bold: true, size: SZ12, font: FONT })], alignment: AlignmentType.LEFT, spacing: SP240 }),
              new Paragraph({ children: [new TextRun({ text: 'ŻANDARMERII WOJSKOWEJ', bold: true, size: SZ12, font: FONT })], alignment: AlignmentType.LEFT, spacing: SP240 }),
              new Paragraph({ children: [new TextRun({ font: FONT, text: '01-163 Warszawa, ul. Żwirki i Wigury 9/13', size: SZ })], alignment: AlignmentType.LEFT, spacing: SP240 }),
              new Paragraph({ children: [new TextRun({ font: FONT, text: 'MILNET-Z: 879-2370', size: SZ, italics: true })], alignment: AlignmentType.LEFT, spacing: SP240 }),
            ]
          }),
          // Prawa: Data
          new TableCell({
            borders: BNONE,
            width: { size: DATE_W2, type: WidthType.DXA },
            verticalAlign: VerticalAlign.TOP,
            children: [
              new Paragraph({ children: [new TextRun({ font: FONT, text: miejsc+', dn. '+dataMeld, size: SZ12 })], alignment: AlignmentType.RIGHT, spacing: SP240 }),
            ]
          }),
        ]
      })
    ]
  });

  // ─── Tytuł (analogicznie do PDF) ────────────────────────────────────────────
  const tPreText = '1. OŻW w Elblągu: meldunek bieżący nr '+nr+'/'+rok+': ';
  const titlePara = new Paragraph({
    children: [
      new TextRun({ font: FONT, text: tPreText, size: SZ12 }),
      new TextRun({ font: FONT, text: (kat !== '_______________' ? kat+'.' : '_______________'), size: SZ12, bold: true })
    ],
    spacing: { before: 200, after: 100, line: 276 }
  });

  // ─── TABELA GŁÓWNA ────────────────────────────────────────────────────────────
  const rows = [];

  // ── Wiersz 0: Data / Godzina / Miejsce zdarzenia — nagłówki ──────────────────
  rows.push(new TableRow({ children: [
    // Lewa pusta komórka (COL[0]) — wiersz 0+1 = rowSpan 2
    wCell('', COL_DXA[0], { rowSpan: 2 }),
    gCell('Data:',              COL_DXA[1], { va: VerticalAlign.CENTER }),
    gCell('Godzina:',           COL_DXA[2], { va: VerticalAlign.CENTER }),
    new TableCell({
      shading: { type: ShadingType.SOLID, color: GRAY, fill: GRAY },
      borders: BALL,
      width: { size: COL_DXA[3]+COL_DXA[4], type: WidthType.DXA },
      columnSpan: 2,
      margins: CMARG,
      children: [new Paragraph({ children: [new TextRun({ font: FONT, text: 'Miejsce zdarzenia:', size: SZ8 })], spacing: SP240 })],
      verticalAlign: VerticalAlign.CENTER
    })
  ]}));
  // ── Wiersz 1: wartości Data / Godzina / Miejsce ───────────────────────────────
  rows.push(new TableRow({ children: [
    wCell(dataZdarz, COL_DXA[1], { bold: true }),
    wCell(godz,      COL_DXA[2], { bold: true }),
    new TableCell({
      borders: BALL,
      width: { size: COL_DXA[3]+COL_DXA[4], type: WidthType.DXA },
      columnSpan: 2,
      margins: CMARG,
      children: [new Paragraph({ children: [new TextRun({ font: FONT, text: miejsce, size: SZ, bold: true })], spacing: SP240 })],
      verticalAlign: VerticalAlign.CENTER
    })
  ]}));

  // ── Wiersze 2-6: Dane sprawców ────────────────────────────────────────────────
  // Etykieta "Dane sprawców" z rowSpan=5 po lewej
  const cat = ['pracownik RON'].includes(stopien)?'ron':['osoba cywilna'].includes(stopien)?'cywilna':stopien?'stopien':null;

  // Etykieta Stopień*/RON*/cywilna — przekreślenia w docx
  function stopienLabelCell() {
    const makeRun = (text, strike) => new TextRun({ font: FONT,
      text, size: SZ8,
      strike: strike || false
    });
    return gCell([
      new Paragraph({
        children: [
          makeRun('Stopień*', cat && cat!=='stopien'),
          makeRun('/', false),
          makeRun('pracownik RON*', cat && cat!=='ron'),
        ],
        spacing: SP240
      }),
      new Paragraph({
        children: [
          makeRun('/', false),
          makeRun('osoba cywilna:', cat && cat!=='cywilna'),
        ],
        spacing: SP240
      })
    ], COL_DXA[1]);
  }

  rows.push(new TableRow({ children: [
    gCell('Dane sprawców:', COL_DXA[0], { rowSpan: 5, va: VerticalAlign.CENTER }),
    stopienLabelCell(),
    gCell('Imię:',      COL_DXA[2]),
    gCell('Nazwisko:',  COL_DXA[3]),
    gCell('Imię ojca:', COL_DXA[4]),
  ]}));
  rows.push(new TableRow({ children: [
    wCell(stopien||'_______________', COL_DXA[1], { bold: true }),
    wCell(imie||'_______________',    COL_DXA[2], { bold: true }),
    wCell(nazwisko||'_______________',COL_DXA[3], { bold: true }),
    wCell(imieOjca||'_______________',COL_DXA[4], { bold: true }),
  ]}));
  rows.push(new TableRow({ children: [
    new TableCell({
      borders: BALL,
      width: { size: COL_REST_DXA, type: WidthType.DXA },
      columnSpan: 4,
      margins: CMARG,
      children: [new Paragraph({ children: [new TextRun({ font: FONT, text: 'PESEL: '+(pesel||'_______________'), size: SZ, bold: true })], spacing: SP240 })],
      verticalAlign: VerticalAlign.CENTER
    })
  ]}));
  rows.push(new TableRow({ children: [
    new TableCell({ shading:{type:ShadingType.SOLID,color:GRAY,fill:GRAY}, borders:BALL, width:{size:COL12_DXA,type:WidthType.DXA}, columnSpan:2, margins:CMARG,
      children:[new Paragraph({children:[new TextRun({ font: FONT,text:'Nazwa Jednostki Wojskowej:',size:SZ8})],spacing:SP240})], verticalAlign:VerticalAlign.CENTER }),
    gCell('Miejscowość:', COL_DXA[3]),
    gCell('Podległość JW:', COL_DXA[4]),
  ]}));
  rows.push(new TableRow({ children: [
    new TableCell({ borders:BALL, width:{size:COL12_DXA,type:WidthType.DXA}, columnSpan:2, margins:CMARG,
      children:[new Paragraph({children:[new TextRun({ font: FONT,text:jednostka,size:SZ,bold:true})],spacing:SP240})], verticalAlign:VerticalAlign.CENTER }),
    wCell(miejscJW,   COL_DXA[3], { bold: true }),
    wCell(podleglosc, COL_DXA[4], { bold: true }),
  ]}));

  // ── Opis zdarzenia + Kwalifikacja prawna czynu ────────────────────────────────
  {
    const opisParas = [];
    // Opis (wieloliniowy, justify-like via LEFT)
    (opis||'_______________').split('\n').forEach(line => {
      opisParas.push(new Paragraph({ children:[new TextRun({ font: FONT,text:line,size:SZ})], alignment:AlignmentType.BOTH, spacing:SP252 }));
    });
    if(kwalBody) {
      opisParas.push(emptyPara(SZ)); // pusta linia
      // Nagłówek kwalifikacji — podkreślony + reszta normalnie
      const firstKwalLine = kwalBody.split('\n')[0];
      opisParas.push(new Paragraph({
        children: [
          new TextRun({ font: FONT, text: 'Kwalifikacja prawna czynu: ', size: SZ, underline: { type: UnderlineType.SINGLE, color: '000000' } }),
          new TextRun({ font: FONT, text: firstKwalLine, size: SZ })
        ],
        spacing: SP252
      }));
      // Kolejne linie kwalifikacji (jeśli są)
      kwalBody.split('\n').slice(1).forEach(line => {
        opisParas.push(new Paragraph({ children:[new TextRun({ font: FONT,text:line,size:SZ})], spacing:SP252 }));
      });
    }
    rows.push(new TableRow({ children: [
      gCell('Krótki opis zdarzenia,\n/kwalifikacja prawna czynu/:', COL_DXA[0], { va: VerticalAlign.TOP }),
      new TableCell({ borders:BALL, width:{size:COL_REST_DXA,type:WidthType.DXA}, columnSpan:4, margins:CMARG, children:opisParas, verticalAlign:VerticalAlign.TOP })
    ]}));
  }

  // ── Co się stało ze sprawcą / pokrzywdzonym ───────────────────────────────────
  {
    // Etykieta z przekreśleniami — docx
    const makeRun8 = (text, strike) => new TextRun({ font: FONT, text, size: SZ8, strike: strike||false });
    const losLabel = [
      new Paragraph({
        children: [
          makeRun8('Co się stało ze ', false),
          makeRun8('sprawcą', losOsoba === 'pokrzywdzony'),
        ],
        spacing: SP240
      }),
      new Paragraph({
        children: [
          makeRun8('/', false),
          makeRun8('pokrzywdzonym:', losOsoba === 'sprawca'),
        ],
        spacing: SP240
      })
    ];
    rows.push(new TableRow({ children: [
      gCell(losLabel, COL_DXA[0], { va: VerticalAlign.CENTER }),
      new TableCell({ borders:BALL, width:{size:COL_REST_DXA,type:WidthType.DXA}, columnSpan:4, margins:CMARG,
        children: los.split('\n').map(l=>new Paragraph({children:[new TextRun({ font: FONT,text:l,size:SZ})],spacing:SP252})),
        verticalAlign: VerticalAlign.TOP
      })
    ]}));
  }

  // ── Stan trzeźwości ────────────────────────────────────────────────────────────
  {
    const makeRun8s = (text, strike) => new TextRun({ font: FONT, text, size: SZ8, strike: strike||false });
    const trzLabel = [
      new Paragraph({ children:[ makeRun8s('Stan trzeźwości', !anyAlk) ], spacing:SP240 }),
      new Paragraph({ children:[ makeRun8s('/obecność środków odurzających', !anyDrg) ], spacing:SP240 }),
      new Paragraph({ children:[ makeRun8s('w organizmie:', !anyDrg) ], spacing:SP240 }),
    ];
    // Sprawca
    rows.push(new TableRow({ children: [
      gCell(trzLabel, COL_DXA[0], { rowSpan: 2, va: VerticalAlign.CENTER }),
      gCell('Sprawca:', COL_DXA[1], { va: VerticalAlign.CENTER }),
      wCell(sprDaneTxt, COL_DXA[2]),
      new TableCell({ borders:BALL, width:{size:COL_DXA[3]+COL_DXA[4],type:WidthType.DXA}, columnSpan:2, margins:CMARG,
        children: sprHasAny ? trzSprStr.split('\n').map(l=>new Paragraph({children:[new TextRun({ font: FONT,text:l,size:SZ})],spacing:SP252}))
                            : [new Paragraph({children:[new TextRun({ font: FONT,text:'_______________',size:SZ})],spacing:SP240})],
        verticalAlign: VerticalAlign.TOP
      })
    ]}));
    // Uczestnik
    rows.push(new TableRow({ children: [
      gCell('Uczestników zdarzenia:', COL_DXA[1], { va: VerticalAlign.CENTER }),
      wCell(uczDaneTxt, COL_DXA[2]),
      new TableCell({ borders:BALL, width:{size:COL_DXA[3]+COL_DXA[4],type:WidthType.DXA}, columnSpan:2, margins:CMARG,
        children: uczHasAny ? trzUczStr.split('\n').map(l=>new Paragraph({children:[new TextRun({ font: FONT,text:l,size:SZ})],spacing:SP252}))
                            : [new Paragraph({children:[new TextRun({ font: FONT,text:'_______________',size:SZ})],spacing:SP240})],
        verticalAlign: VerticalAlign.TOP
      })
    ]}));
  }

  // ── Nazwa instytucji zabezpieczającej ─────────────────────────────────────────
  rows.push(new TableRow({ children: [
    gCell('Nazwa instytucji zabezpieczającej miejsce zdarzenia:', COL_DXA[0]),
    wCell(inst, COL_REST_DXA, { colSpan: 4 })
  ]}));

  // ── Czynności wykonane na miejscu zdarzenia ───────────────────────────────────
  {
    const czParas = czynnosciLines.length
      ? czynnosciLines.map(item => new Paragraph({
          children: [new TextRun({
            font: FONT, text: item.text, size: SZ,
            underline: item.underline ? { type: UnderlineType.SINGLE, color: '000000' } : undefined
          })],
          spacing: SP252
        }))
      : [new Paragraph({children:[new TextRun({ font: FONT,text:'_______________',size:SZ})],spacing:SP240})];
    rows.push(new TableRow({ children: [
      gCell('Czynności wykonane na miejscu zdarzenia:', COL_DXA[0], { va: VerticalAlign.TOP }),
      new TableCell({ borders:BALL, width:{size:COL_REST_DXA,type:WidthType.DXA}, columnSpan:4, margins:CMARG, children:czParas, verticalAlign:VerticalAlign.TOP })
    ]}));
  }

  // ── Środki przymusu ────────────────────────────────────────────────────────────
  rows.push(new TableRow({ children: [
    gCell('Zastosowane środki przymusu bezpośredniego:', COL_DXA[0]),
    wCell(przymus, COL_REST_DXA, { colSpan: 4 })
  ]}));

  // ── Sposób dalszego postępowania ──────────────────────────────────────────────
  rows.push(new TableRow({ children: [
    gCell('Sposób dalszego postępowania, zakończenia zdarzenia:', COL_DXA[0], { va: VerticalAlign.TOP }),
    new TableCell({ borders:BALL, width:{size:COL_REST_DXA,type:WidthType.DXA}, columnSpan:4, margins:CMARG,
      children: post.split('\n').map(l=>new Paragraph({children:[new TextRun({ font: FONT,text:l,size:SZ})],spacing:SP252})),
      verticalAlign: VerticalAlign.TOP
    })
  ]}));

  // ── Kto prowadzi dalsze postępowanie ──────────────────────────────────────────
  rows.push(new TableRow({ children: [
    gCell('Kto prowadzi dalsze postępowanie:', COL_DXA[0]),
    wCell(dalsze, COL_REST_DXA, { colSpan: 4 })
  ]}));

  // ── Inne uwagi ─────────────────────────────────────────────────────────────────
  rows.push(new TableRow({ children: [
    gCell('Inne uwagi:', COL_DXA[0]),
    wCell(uwagi, COL_REST_DXA, { colSpan: 4 })
  ]}));

  // ─── Tabela główna ────────────────────────────────────────────────────────────
  const mainTable = new Table({
    width: { size: CW_DXA, type: WidthType.DXA },
    borders: BALL,
    rows: rows
  });

  // ─── Podpis OD ────────────────────────────────────────────────────────────────
  const sigLines = ['OFICER DYŻURNY', 'Oddziału Żandarmerii Wojskowej', 'w Elblągu', '/-/ '+oficer];
  const sigParas = sigLines.map(ln => new Paragraph({
    children: [new TextRun({ font: FONT, text: ln, bold: true, size: SZ_SIG })],
    alignment: AlignmentType.RIGHT,
    spacing: { line: 276 }
  }));

  // ─── Dokument końcowy ─────────────────────────────────────────────────────────
  const docObj = new Document({
    styles: {
      default: {
        run: { font: 'Arial', size: 20 }
      }
    },
    sections: [{
      properties: {
        page: {
          margin: { top: 1440, bottom: 1440, left: 1083, right: 1083 }
        }
      },
      children: [
        headerTable,
        emptyPara(SZ),
        titlePara,
        mainTable,
        emptyPara(SZ),
        emptyPara(SZ),
        ...sigParas
      ]
    }]
  });

  // ─── Zapis ────────────────────────────────────────────────────────────────────
  const blob = await Packer.toBlob(docObj);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'Meldunek_Biezacy_'+nr+'_'+rok+'.docx';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(()=>URL.revokeObjectURL(a.href), 10000);
});

})();
