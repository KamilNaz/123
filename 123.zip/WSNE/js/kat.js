var KAT_NAMES = {
  'I':    'Zdarzenia stanowiące lub mogące stanowić zagrożenie dla bezpieczeństwa Rzeczypospolitej Polskiej lub pokoju międzynarodowego',
  'II':   'Wypadki i naruszenia dyscypliny z udziałem personelu RON',
  'III':  'Zdarzenia dotyczące naruszeń systemu ochrony obiektów wojskowych',
  'IV':   'Zdarzenia dotyczące obiektów, w których realizowane są zadania na rzecz Sił Zbrojnych RP',
  'V':    'Zdarzenia dotyczące zagrożeń o charakterze niemilitarnym, w tym terrorystyczne',
  'VI':   'Zdarzenia w środowisku informacyjnym i cyberprzestrzeni',
  'VII':  'Zdarzenia w Polskich Kontyngentach Wojskowych (PKW)',
  'VIII': 'Zdarzenia z udziałem personelu sił zbrojnych innych państw, realizujących zadania na terytorium RP lub tranzyt przez terytorium RP',
  'IX':   'Inne zdarzenia nadzwyczajne'
};

function _range(n) { return Array.from({length: n}, function(_,i){ return String(i+1); }); }

var KAT_SUB = {
  'I':    _range(41),
  'II':   ['1W','2W','3W','4W','5W','6Wa','6Wb','7W','8Wa','8Wb','9Wa','9Wb',
           '1N','2N','3N','4N','5N','6N','7Na','7Nb','8N','9N','10N','11N','12N','13N','14N','15N'],
  'III':  _range(8),
  'IV':   _range(9),
  'V':    _range(14),
  'VI':   _range(5),
  'VII':  _range(11),
  'VIII': _range(9),
  'IX':   _range(5)
};

window.updateKatSub = function(val) {
  var sub = document.getElementById('katSubZdarzenia');
  if (!sub) return;
  if (!val || !KAT_SUB[val]) {
    sub.innerHTML = '<option value="">-- Najpierw wybierz kategorię powyżej --</option>';
    sub.disabled = true;
    return;
  }
  sub.disabled = false;
  var name = KAT_NAMES[val];
  var opts = '<option value="">-- Wybierz podkategorię --</option>';
  KAT_SUB[val].forEach(function(code) {
    var label = name + ' (' + val + '/' + code + ')';
    opts += '<option value="' + label + '">' + val + '/' + code + '</option>';
  });
  sub.innerHTML = opts;
};
