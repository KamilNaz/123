const KAT_SUB = {
  'I': [
    'kolizja drogowa wpm/ppm (kat. I/1)',
    'wypadek drogowy wpm/ppm (kat. I/2)',
    'wypadek drogowy z udziałem pojazdów wojskowych i cywilnych (kat. I/3)',
    'śmierć żołnierza – naturalna (kat. I/4N)',
    'śmierć żołnierza – nagła/niewyjaśniona (kat. I/4NN)',
    'śmierć żołnierza – wypadek (kat. I/4W)',
    'śmierć żołnierza – samobójstwo (kat. I/4S)',
    'zaginięcie żołnierza (kat. I/5)',
    'wypadek lotniczy (kat. I/6)',
    'wypadek przy użyciu uzbrojenia/sprzętu wojskowego (kat. I/7)',
    'samookaleczenie żołnierza (kat. I/8)'
  ],
  'II': [
    'wtargnięcie na teren JW (kat. II/1)',
    'rejestrowanie obiektu JW (kat. II/2)',
    'niekontrolowany lot BSP nad terenem JW (kat. II/3)',
    'działania rozpoznawcze przeciwko obiektom wojskowym (kat. II/4)',
    'kradzież mienia wojskowego (kat. II/5K)',
    'zniszczenie mienia wojskowego (kat. II/5Z)',
    'samowolne oddalenie żołnierza (kat. II/6)',
    'samowolne oddalenie żołnierza z bronią (kat. II/6B)',
    'niekontrolowany strzał (kat. II/7)',
    'stan nietrzeźwości żołnierza w miejscu służby (kat. II/8A)',
    'stan nietrzeźwości żołnierza poza służbą (kat. II/8B)',
    'naruszenie przepisów o środkach odurzających (kat. II/9)',
    'pobicie/bójka z udziałem żołnierza (kat. II/10)',
    'interwencja domowa z udziałem żołnierza (kat. II/11)',
    'popełnienie innego czynu zabronionego przez personel RON, szczególnie w stanie nietrzeźwości lub odurzenia (kat. II/14N)',
    'inne zdarzenie prewencyjne (kat. II/14)'
  ],
  'III': [
    'zdarzenie z udziałem żołnierzy sił sojuszniczych (kat. III/1)',
    'naruszenie przepisów o ochronie informacji niejawnych (kat. III/2)',
    'próba samobójcza żołnierza (kat. III/3)'
  ]
};

function updateKatSub(val) {
  const sub = document.getElementById('katSubZdarzenia');
  if (!val || !KAT_SUB[val]) {
    sub.innerHTML = '<option value="">-- Najpierw wybierz kategorię --</option>';
    sub.disabled = true;
    return;
  }
  sub.disabled = false;
  sub.innerHTML = '<option value="">-- Wybierz podkategorię --</option>' +
    KAT_SUB[val].map(o => `<option value="${o}">${o}</option>`).join('');
}